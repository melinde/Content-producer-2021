<?php get_header(); ?>
<div class="page-banner">
  <div class="page-banner__bg-image" style="background-image: url(<?php echo get_theme_file_uri('images/library-hero.jpg') ?>);"></div>
  <div class="page-banner__content container t-center c-white">
    <h1 class="headline headline--large">Velkommen!</h1>
    <h2 class="headline headline--medium">Du vil få nogle fantasiske studieår her.</h2>
    <h3 class="headline headline--small">Hvorfor ikke se hvem dine <strong>undervisere</strong> er?</h3>
    <a href="#" class="btn btn--large btn--blue">Find din underviser</a>
  </div>
</div>

<div class="full-width-split group">
  <div class="full-width-split__one">
    <div class="full-width-split__inner">
      <h2 class="headline headline--small-plus t-center">Kommende begivenheder</h2>

      <div class="event-summary">
        <a class="event-summary__date t-center" href="#">
          <span class="event-summary__month">Mar</span>
          <span class="event-summary__day">25</span>
        </a>
        <div class="event-summary__content">
          <h5 class="event-summary__title headline headline--tiny"><a href="#">Fotokonkurrence</a></h5>
          <p>Kom til bygning 4 med dit bedste billede og deltag i konkurrencen om et nyt kamera.<a href="#" class="nu gray"> Læs mere</a></p>

        </div>
      </div>
      <div class="event-summary">
        <a class="event-summary__date t-center" href="#">
          <span class="event-summary__month">Apr</span>
          <span class="event-summary__day">02</span>
        </a>
        <div class="event-summary__content">
          <h5 class="event-summary__title headline headline--tiny"><a href="#">Quad Picnic Party</a></h5>
          <p>Live musik, en mexikansk taco truck og meget mere på vores tredje årlige picnic dag.<a href="#" class="nu gray"> Læs mere</a></p>
        </div>
      </div>

      <p class="t-center no-margin"><a href="#" class="btn btn--blue">Se alle events</a></p>
    </div>
  </div>
  <div class="full-width-split__two">
    <div class="full-width-split__inner">
      <h2 class="headline headline--small-plus t-center">Fra vores blog</h2>

      <div class="event-summary">
        <a class="event-summary__date event-summary__date--beige t-center" href="#">
          <span class="event-summary__month">Jan</span>
          <span class="event-summary__day">20</span>
        </a>
        <div class="event-summary__content">
          <h5 class="event-summary__title headline headline--tiny"><a href="#">Vi er den bedste skole</a></h5>
          <p>For 10. år i træk har vi vundet #1. <a href="#" class="nu gray">Læs mere</a></p>
        </div>
      </div>
      <div class="event-summary">
        <a class="event-summary__date event-summary__date--beige t-center" href="#">
          <span class="event-summary__month">Feb</span>
          <span class="event-summary__day">04</span>
        </a>
        <div class="event-summary__content">
          <h5 class="event-summary__title headline headline--tiny"><a href="#">Besøg af internationale gæsteundervisere</a></h5>
          <p>Igen i år får vi besøg af gæsteundervisere fra både Italien og Canada. <a href="#" class="nu gray">Læs mere</a></p>
        </div>
      </div>

      <p class="t-center no-margin"><a href="#" class="btn btn--yellow">Se alle blogindlæg</a></p>
    </div>
  </div>
</div>

<div class="hero-slider">
  <div data-glide-el="track" class="glide__track">
    <div class="glide__slides">
      <div class="hero-slider__slide" style="background-image: url(<?php echo get_theme_file_uri('images/bus.jpg') ?>);">
        <div class="hero-slider__interior container">
          <div class="hero-slider__overlay">
            <h2 class="headline headline--medium t-center">Fri transport til skolen</h2>
            <p class="t-center">Alle studende har fri transport med bus til skolen.</p>
            <p class="t-center no-margin"><a href="#" class="btn btn--blue">Læs mere</a></p>
          </div>
        </div>
      </div>
      <div class="hero-slider__slide" style="background-image: url(<?php echo get_theme_file_uri('images/apples.jpg') ?>);">
        <div class="hero-slider__interior container">
          <div class="hero-slider__overlay">
            <h2 class="headline headline--medium t-center">Frugt hver dag</h2>
            <p class="t-center">Vi anbefaler at du altid spiser frugt i løbet af dagen.</p>
            <p class="t-center no-margin"><a href="#" class="btn btn--blue">Læs mere</a></p>
          </div>
        </div>
      </div>
      <div class="hero-slider__slide" style="background-image: url(<?php echo get_theme_file_uri('images/bread.jpg') ?>);">
        <div class="hero-slider__interior container">
          <div class="hero-slider__overlay">
            <h2 class="headline headline--medium t-center">Gratis frokost</h2>
            <p class="t-center">Lyngby akademi tilbyder gratis frokost til studerende med særlige økonomiske udfordringer.</p>
            <p class="t-center no-margin"><a href="#" class="btn btn--blue">Læs mere</a></p>
          </div>
        </div>
      </div>
    </div>
    <div class="slider__bullets glide__bullets" data-glide-el="controls[nav]"></div>
  </div>
</div>
<?php
get_footer();
 ?>
